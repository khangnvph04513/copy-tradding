const authtoken = require('./auth/auth-token');
const api = require('./api/binary-option-api/binary-api');
const authIndex = require('./index');
